# MobileApplicationsDevelopment
Materials to the course "Mobile Applications Development"

**@Lenmar Abdurayimov**  
**2023**

